
export interface User {
    userId: number;
    userName: string;
    userEmail: string;
    userPhonenumber: string;
    userPassword: string;
    userRole : string;
    employersEmployerId: number;
    employeesEmployeeId: number;

    
}

